/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectprogramhash;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author vicente-jpro
 */
public class Agenda {
    //private ArrayList <LinkedList<String>> tabela = new ArrayList<LinkedList<String>>();

    private List<List<Actividade>> tabela_HASH = new ArrayList<List<Actividade>>();
    private int tamanho, T = 0;

    private List<Actividade> listaDeActividades;

    public Agenda(int tamanho) {
        this.tamanho = tamanho; // n
        for (int i = 0; i < this.tamanho; i++) { // n
            LinkedList<Actividade> lista = new LinkedList<Actividade>(); // n
            tabela_HASH.add(lista); // 1
        }
        /*
        Complexidade: g(n) = 3n + 1 => O(n) = n
        
         */
    }

    private int calculaIndiceDaTabela(int id) {
        return id % this.tamanho; // 1
        /*
        Complexidade: g(n) = 1 => O(n) = 1
        
         */
    }

    public void adiciona(Actividade nova) {
        if (!this.contem(nova.id)) { // 1
            int indice = this.calculaIndiceDaTabela(nova.id);  //2
            // Uma n operacões na para a busca do indice mais 1 atribuição
            List<Actividade> lista = this.tabela_HASH.get(indice); // n + 1
            lista.add(nova); // 1
            this.T++; // 1
        }
        /*
        Complexidade: g(n) = n + 6 => O(n) = n
        
         */
    }

    public void remove(int id) {
        if (this.contem(id)) { // 1
            int indice = this.calculaIndiceDaTabela(id); // 2
            // Uma n operacões na para a busca do indice mais 1 atribuição
            List<Actividade> lista = this.tabela_HASH.get(indice); // n + 1
            lista.remove(id); // n
        }

        /*
        Complexidade: g(n) = 2n + 4 => O(n) = n
        
         */
    }

    public boolean contem(int id) {
        // Uma operação e uma atribuição
        int indice = this.calculaIndiceDaTabela(id); // 2
        // Uma n operacões na para a busca do indice mais 1 atribuição
        List<Actividade> lista = this.tabela_HASH.get(indice); // n + 1

        return lista.contains(id); // 1
        /*
        Complexidade: g(n) = n + 4 => O(n) = n
        
         */
    }

    public List<Actividade> pegaTodas() {
        List<Actividade> palavras = new ArrayList<Actividade>(); // 1

        for (int i = 0; i < this.tabela_HASH.size(); i++) { // n
            palavras.addAll(this.tabela_HASH.get(i)); // n

        }

        return palavras; //1
        /*
        Complexidade: g(n) = 2n + 2 => O(n) = n
        
         */
    }

    public int tamanho() {
        // implementação
        return this.T; // 1
    }

    //_--------------------------- Outros metodos essencias
    public Actividade editarActividade(int id) {
        listaDeActividades = pegaTodas(); //  2n + 2 + 1
        return listaDeActividades.get(id); // n + 1
        /*
        Complexidade: g(n) = 2n + 3 => O(n) = n
        
         */
    }

   public boolean verificarRegisto(String nome) {

        listaDeActividades = pegaTodas(); // 2n + 2

        if (!vazia()) { // 1

            for (Actividade actividade : listaDeActividades) { // n
                String nomeProjecto = actividade.projeto; // n 
                // Se a actividade existe 
                if (nomeProjecto.equalsIgnoreCase(nome)) { // n
                    return true; // 1
                }
            }

        }

        return false; // 1
        /*
        Complexidade: g(n) = 5n + 5 => O(n) = n
        
         */
    }

   public boolean verificarDataRegisto(Data dataInserida) {

        listaDeActividades = pegaTodas(); // 2n + 2

        
        if (!vazia()) { // 1
            String dataDaActividade = ""; // 1
            for (Actividade actividade : listaDeActividades) { // n
                // Se a actividade existe 
                if (actividade.dataDaActividade.dia == dataInserida.dia) { // n
                    dataDaActividade = actividade.dataDaActividade.getMes(); // n
                    if (dataDaActividade.equalsIgnoreCase(dataInserida.getMes())) { // n
                        if (actividade.dataDaActividade.ano == dataInserida.ano) { // n
                            return true; // 1
                        }
                    }
                }
               
            }
            

        }

        
        return false; // 1

        /*
        Complexidade: g(n) = 7n + 6 => O(n) = n
        
         */
    }

    //Verificar a existência de um registo especifico em um intervalo de hora
  public  boolean verificarIntervaloHoraRegisto(Hora horaInical, Hora horaFinal) {

        listaDeActividades = pegaTodas(); // 2n + 2

        if (!vazia()) { // 1

            for (Actividade actividade : listaDeActividades) { // n

                int horaRegisto = actividade.hora.hora; // n
                System.out.println("\n Hora registo: " + horaRegisto); // n
                if (horaInical.hora <= horaRegisto) { // n
                    if (horaRegisto <= horaFinal.hora) { // n
                        return true; // 1
                    }
                }

            }

        }

        return false; // 1
        /*
        Complexidade: g(n) = 7n + 5 => O(n) = n
        
         */
    }

    // verificar se a estrutura está vazia
    public boolean vazia() {

        return listaDeActividades.isEmpty(); // 1
    }

    // pegar o Actividade relacionada a um mẽs
    public Object[] verificarDiasVaziosMes(Data data) {

        listaDeActividades = pegaTodas();  // 2n + 2

        Object[] diasDoMes = new Object[31]; // 1
        String mesInserido = null; // 1
        if (!vazia()) { // 1

            int posicao = 0; // 1
            // Pervorrer todas as actividades
            for (Actividade actividade : listaDeActividades) { // n

                String mesRegisto = actividade.dataDaActividade.getMes(); // n
                mesInserido = data.getMes(); // n
                // Se o mes da actifidade for igual ao mes digitado
                if (mesRegisto.equalsIgnoreCase(mesInserido)) { // n

                    // pegar o dia do registo da actividade
                    int dia = actividade.dataDaActividade.dia; // n
                    // colocar o dia em um array de meses
                    diasDoMes[dia - 1] = dia; // n

                }
                posicao++; // n
            }

        }

        return diasDoMes; // 1
        /*
        Complexidade: g(n) = 9n + 7 => O(n) = n
        
         */
    }

    public Object[] verificarMesesVaziosAno(Data data) {

        listaDeActividades = pegaTodas(); // 2n + 2

        Object[] mesDoAno = new String[12]; // 1
        String mes = ""; // 1
        int anoInserido = 0; // 1
        ;
        if (!vazia()) { // 1

            int posicao = 0; // 1
            // Pervorrer todas as actividades
            for (Actividade actividade : listaDeActividades) { // n

                int anoRegisto = actividade.dataDaActividade.ano; // n
                anoInserido = data.ano; // n
                // Se o ano da actifidade for igual ao ano digitado
                if (anoRegisto == anoInserido) { // n

                    // pegar o mes do registo da actividade
                    mes = actividade.dataDaActividade.getMes(); // n
                    int posicaoMes = actividade.dataDaActividade.getPosicaoMes(); // n 
                    // colocar o mes em um array de meses
                    mesDoAno[posicaoMes] = mes; // n

                }
                posicao++; // n
            }

        }

        return mesDoAno; // 1
        /*
        Complexidade: g(n) = 10n + 8 => O(n) = n
        
         */
    }

    // verificar meses com mais demanda
    public List<Demanda> verificarMesesMaisDemanda() {

        listaDeActividades = pegaTodas(); // 2n + 2

        Data data = new Data(); // 1
        List<Demanda> listaDemanda = new ArrayList<>(); // 1

        // Apenas copia todos os meses para a variavel meses
        String[] meses = data.getTodosMeses(); // 1

        int numeroDemanda = 0; // 1

        if (!vazia()) { // 1

            Demanda deman = null; // 1
            String mesRegisto = "não definido"; // 1
            // Pervorrer todas as actividades
            for (Actividade actividade : listaDeActividades) { // n

                if (deman == null) { // n

                    deman = new Demanda(0, ""); // n
                    listaDemanda.add(deman); // n
                }

                String mesActividade = actividade.dataDaActividade.getMes(); // n

                // Se o mês de registo da actividade for diferente do mesRegisto, então
                // Coloca na variavel mesRegisto 
                if (!mesRegisto.equalsIgnoreCase(mesActividade)) { // n
                    mesRegisto = mesActividade; // n

                    deman = new Demanda(1, mesActividade); // n
                    listaDemanda.add(deman); // n
                    // reinicia a contagem da demanda
                    numeroDemanda = 0; // n

                }

                if (!listaDemanda.isEmpty()) { // n

                    for (int i = 0; i < listaDemanda.size(); i++) {// n*n
                        String mesDaListaDemanda = listaDemanda.get(i).getMes(); // n*n

                        if (mesRegisto.equalsIgnoreCase(mesDaListaDemanda)) { // n*n

                            numeroDemanda = listaDemanda.get(i).numeroDemanda + 1; // n*n

                            deman = new Demanda(numeroDemanda, mesDaListaDemanda); // n*n
                            listaDemanda.set(i, deman); // n*n
                        }
                    }
                }

            }

        }

        return listaDemanda; // 1

        /*
        Complexidade: g(n) = 6n² +13n + 9 => O(n) = n
        
         */
    }

    // Pegar os meses com mais demanda
    public List<Demanda> getMesComMaisDemanda(String opcao) {

        listaDeActividades = pegaTodas(); // 2n + 2

        List<Demanda> listaDemanda = verificarMesesMaisDemanda(); // 6n² +13n + 9
        int demanda1;
        int demanda2;
        if (!listaDemanda.isEmpty()) { // 1
            for (int i = 0; i < listaDemanda.size(); i++) { // n

                for (int j = i + 1; j < listaDemanda.size(); j++) { // n*n - 1

                    demanda1 = listaDemanda.get(i).numeroDemanda;  // n*n - 1
                    demanda2 = listaDemanda.get(j).numeroDemanda; // n*n - 1

                    if (opcao.equalsIgnoreCase("mes com mais demanda")) { // n*n - 1
                        // Remove o mês com menor demanda
                        if (demanda1 > demanda2) { // n*n - 1
                            listaDemanda.remove(j); // n*n - 1
                        }
                    } else { // n*n - 1
                        // mes com menos demanda
                        // Remove o mês com mais demanda
                        if (demanda1 < demanda2) { // n*n - 1
                            listaDemanda.remove(j); // n*n - 1
                        }
                    }

                }

            }
        }

        return listaDemanda; // 1
        /*
        Complexidade: g(n) = 14n² +16n - 4 => O(n) = n²
        
         */

    }

    public void mostrarTodosRegistos() {

        listaDeActividades = pegaTodas(); // 2n + 2

        System.err.println("********** Todas as Actividade **********"); // 1
        for (Actividade actividade : listaDeActividades) { // n

            System.err.println(actividade.toString()); // n

        }
        System.err.println("**********************************\n"); // n
        /*
        Complexidade: g(n) = 5n + 3 => O(n) = n
        
         */

    }

    public void imprimirDemanda(List<Demanda> listaDemanda) {

        for (Demanda demanda : listaDemanda) { // n

            System.err.println(demanda.toString()); // n

        }

        /*
        Complexidade: g(n) = 2n => O(n) = n
        
         */
    }

    public void imprimirArrayDias(Object[] array) {

        for (int i = 0; i < array.length; i++) { // n

            String mudarLinhaDia = (i % 7 == 0) ? "\n" : ""; // n

            // Se o mês estiver vazio, mostra o dia
            if (array[i] == null) { // n

                System.err.print(" " + (i + 1) + mudarLinhaDia); // n

            }

        }

        /*
        Complexidade: g(n) = 4n  => O(n) = n
        
         */
    }

    public void imprimirArrayMeses(Object[] array) {

        Data data = new Data(); // 1
        String[] meses = data.getTodosMeses(); // 1

        for (int i = 0; i < array.length; i++) { // n

            for (int j = 0; j < meses.length; j++) { // n*n

                if (array[i] == meses[j]) { // n*n
                    meses[j] = "Agendado"; // n*n
                }
            }

        }

        // imprimir meses vazios
        for (int i = 0; i < meses.length; i++) { // n 

            String mudarLinhaMes = (i % 4 == 0) ? "\n" : ""; // n
            // Se o mês estiver vazio, mostra o dia

            System.err.println("  " + meses[i] + mudarLinhaMes); // n

        }

    }
    /*
        Complexidade: g(n) = 3n² + 4n + 2 => O(n) = n
        
     */

}
