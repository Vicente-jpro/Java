/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectprogramhash;


public class Hora {
    int hora;
    int minuto;
    int segundo;
    
    @Override
    public String toString(){
    
        return hora +":"+minuto+":"+segundo;
    }
    
}
