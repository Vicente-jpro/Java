/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectprogramhash;

/**
 *
 * @author vicente-jpro
 */
public class Demanda extends Data{
    int numeroDemanda;
    String mes;
    public Demanda(int numeroDemanda, String mes) {
       
        this.numeroDemanda = numeroDemanda;
        this.mes = mes;
        
    }
    
    
    public String toString(){
     return numeroDemanda+" - "+mes;
    }
}
