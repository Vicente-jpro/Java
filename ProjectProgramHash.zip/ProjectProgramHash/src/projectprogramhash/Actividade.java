/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectprogramhash;


public class Actividade {
    String diaDaSemana;
    Data dataDaActividade;
    Hora hora;
    String descricaoDaActividade;
    String local;
    Data lembrete;
    boolean periodicidadeHabitual;
    String projeto;
    int id;
         
    
        @Override
    public String toString(){

          String periodicidade = (periodicidadeHabitual == true) ? "habitual" : "pontual";
          
          return    "\n Id: " + id
                    + "\n Projecto: " + projeto
                    + "\n Descricão: " + descricaoDaActividade
                    + "\n Data: " + dataDaActividade.toString()
                    + "\n Hora: " + hora.toString()
                    + "\n Dia da Semana: " + diaDaSemana
                    + "\n Lembrete: " + lembrete.toString()
                    + "\n Local: " + local
                    + "\n Periodicidade: " + periodicidade
            ;
    
    }
    
}
