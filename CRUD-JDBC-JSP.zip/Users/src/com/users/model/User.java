package com.users.model;

public class User {
	private String nome, senha;
	private int id_usuario;


	
	public User(int id_usuario) {
		
		this.id_usuario = id_usuario;
	}
	

	public User(String nome, String senha, int id_usuario) {
		super();
		this.nome = nome;
		this.senha = senha;
		this.id_usuario = id_usuario;
	}
	
	public User(String nome, String senha) {
		super();
		this.nome = nome;
		this.senha = senha;
	}




	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public int getId_usuario() {
		return id_usuario;
	}

	public void setId_usuario(int id_usuario) {
		this.id_usuario = id_usuario;
	}

	
	
}
