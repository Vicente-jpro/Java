package com.users.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;

import ConectionJDBC.ConnectionJDBC;

public class Userdb {

	private Connection conn;
	private PreparedStatement stmt;
	private ResultSet rs;

	public Userdb() {

		conn = ConnectionJDBC.getConnection();

	}
//	
//	SELECT id_usuario, nome, senha
//	FROM public.usuario_tb;

	public void create(User user) {

		String sql = "INSERT INTO usuario_tb (nome, senha) VALUES ( ?, ? )";

		try {
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, user.getNome());
			stmt.setString(2, user.getSenha());
			stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(conn, stmt);
		}

	}

	public void update(User user) {

		String sql = "UPDATE usuario_tb  "
				+ " SET nome = ?, senha = ?  "
				+ " WHERE id_usuario = ?";

		try {
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, user.getNome());
			stmt.setString(2, user.getSenha());
			stmt.setInt(3, user.getId_usuario());
			stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(conn, stmt);
		}

	}

	public void delete(User user) {

		String sql = "DELETE FROM usuario_tb WHERE id_usuario = ? ";

		try {
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, user.getId_usuario());
			stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(conn, stmt);
		}

	}

	public List<User> read() {

		String sql = "	SELECT id_usuario, nome, senha"
				+ "	FROM public.usuario_tb "
				+ " ORDER BY id_usuario";

		User user;

		List lista = new ArrayList<User>();
		try {

			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();

			while (rs.next()) {
				user = new User(

						rs.getString("nome"), rs.getString("senha"), rs.getInt("id_usuario"));
				lista.add(user);

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(conn, stmt, rs);
		}
		return lista;

	}

	public User getUser(int id_usuario) {

		
		String sql = "	SELECT id_usuario, nome, senha 	FROM public.usuario_tb WHERE id_usuario = "+id_usuario;

		User user = null;
		try {

			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();

			rs.next();
			user = new User(

					rs.getString("nome"), rs.getString("senha"), rs.getInt("id_usuario"));

		//	System.out.println("nome ="+user.getNome()+" ID: "+user.getId_usuario());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			ConnectionJDBC.closeConnection(conn, stmt, rs);
		}
		return user;

	}

}
