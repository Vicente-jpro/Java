package com.users.controller;

import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.security.auth.NTSidUserPrincipal;
import com.users.model.User;
import com.users.model.Userdb;

/**
 * Servlet implementation class Users
 */
@WebServlet("/UsersController")
public class UsersController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String USER_FORM = "user-form.jsp";
	private static final String USERS_LIST = "user-list.jsp";
	private User user;
	private Userdb userdb;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UsersController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String page = null;
		String action = request.getParameter("action");
		int idUsuario = 0;
		userdb = new Userdb();
		
		switch (action) {
		case "refresh":
			page = USERS_LIST;
			listar(request, response);
			break;
		case "edit":

			page = USER_FORM;
			idUsuario = Integer.parseInt(request.getParameter("id_usuario"));
			
			user = userdb.getUser(idUsuario);
			request.setAttribute("usuario", user);
			listar(request, response);
			break;
		case "delete":
			
			  page = USERS_LIST;
			  idUsuario = Integer.parseInt(request.getParameter("id_usuario"));
			  user = new User(idUsuario);
			  
			  userdb.delete(user);
			  listar(request, response);
			  break;
			  
		case "newUser":
			page = USER_FORM;
			break;
		default:
			break;
		}

		System.out.println("Id Usuario : "+idUsuario);
		RequestDispatcher view = request.getRequestDispatcher(page);
		view.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String page = USERS_LIST;
		String id = request.getParameter("id_usuario");
		String nome = request.getParameter("nome"), senha = request.getParameter("senha");
		userdb = new Userdb();
		
		if (id != null) {

			int id_usuario = Integer.parseInt(id);
			user = new User(nome, senha, id_usuario);
			userdb.update(user);

		} else {

			user = new User(nome, senha);
			userdb.create(user);

		}

		listar(request, response);
		RequestDispatcher view = request.getRequestDispatcher(page);
		view.forward(request, response);

	}

	private void listar(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		userdb = new Userdb();
		List<User> lista = userdb.read();
		request.setAttribute("listaDeUsuarios", lista);

	}

}
