package InterfacesJframe;

/*-----------------------------------
Nome: Leitícia Da Costa, 20229
FileName: clienteModelo.java
Data de criação: 26.11.2019
----------------------------------#*/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import static jdk.nashorn.internal.runtime.Debug.id;
import projdeprogramacao3.Actividade;


public class ClienteVisao extends JFrame
{
	private PainelCentro centro;
	private PainelSul sul;
	
	public ClienteVisao()
	{
		super("Cadastrar Clientes");
		getContentPane().add(centro = new PainelCentro(), BorderLayout.CENTER);
		getContentPane().add(sul = new PainelSul(), BorderLayout.SOUTH);
	
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ImageIcon imgProjecto = new ImageIcon("Icons_Projecto/IMGSEE.png");
		setIconImage(imgProjecto.getImage()); 
		setSize(470,345);
		setVisible(true);
		setResizable(false);
		setLocationRelativeTo(null);
	}
	
//------------------------------------------ Class Interna Painel Centro -----------------------------------------------------------
	class PainelCentro extends JPanel
	{
		private JTextField codigoJT, nomeProjectoJT, descricaoJT, anoJT, diaJT, mesJT;
		private JLabel codigoJL, nomeProjectJL, descricaoJL, periodicidade ,lbMorada, lbIva,
                        anoJL, diaJL, mesJL;
		private JRadioButton habitual, pontual;
		private JComboBox cmbMorada;
		private ButtonGroup grupo;
		private JComboBox cmbIva;
		private Actividade actividade ;
		public PainelCentro()
		{	
			setLayout(new GridLayout(5,2));
			setBackground(Color.WHITE);
			actividade = new Actividade();
			add(codigoJL = new JLabel("Codigo"));
			codigoJT = new JTextField(10);
                        codigoJT.setText( String.valueOf(actividade.getId()));
                        add(codigoJT);
                        
		
			codigoJT.setFocusable(false);
			
			add(nomeProjectJL = new JLabel("Nome do Projecto"));
			add(nomeProjectoJT = new JTextField(25));
			
			add(descricaoJL = new JLabel("Descricao"));
			add(descricaoJT = new JTextField(15));
			
			add(lbMorada = new JLabel("Morada"));
			
			add(lbIva = new JLabel("Iva"));
			

			add(periodicidade = new JLabel("Sexo"));
			habitual = new JRadioButton("Habitual" , true);
			pontual = new JRadioButton("Pontual");
			ButtonGroup grupo = new ButtonGroup();
			grupo.add(habitual);
			grupo.add(pontual);
			JPanel painelRadio = new JPanel();
			painelRadio.add(habitual);
			painelRadio.add(pontual);
			add(painelRadio);
			pontual.setBackground(Color.WHITE);
			habitual.setBackground(Color.WHITE);
			painelRadio.setBackground(Color.WHITE);
		}
		
//----------------------------------------------- Metodo Get do ClienteVisao -------------------------------------------------------		
		public String getNome()
		{
			return nomeProjectoJT.getText().trim();
		}
		public String getTelefone()
		{
			return descricaoJT.getText().trim();
		}
		public String getMorada()
		{
			return cmbMorada.getSelectedItem().toString();
		}
		public String getSexo()
		{
			if(habitual.isSelected())
				return "Masculino";
			else
				return "Femenino";
		}
		public int getCodigo()
		{
			int codigo = 0;
			
			try
			{
				codigo = Integer.parseInt(codigoJT.getText().trim());
			}
			catch(NumberFormatException ex)
			{
				ex.printStackTrace();
			}
			return codigo;
		}
		
		public void limparCampos()
		{
			nomeProjectoJT.setText("");
			descricaoJT.setText("");
			cmbMorada.setSelectedIndex(-1);
			cmbIva.setSelectedIndex(-1);
		}
		
		public boolean dadosValidos()
		{
			if(getNome().equals("") || getCodigo() <= 0)
				return false;
			return true;
		}
		
		
	

	}
	
//----------------------------------------- Class Interna Painel Sul ------------------------------------------------------------
	class PainelSul extends JPanel implements ActionListener
	{
		private JButton btnSalvar, btnLimpar, btnSair;
		
		public PainelSul()
		{
			setLayout(new GridLayout(1,3));
			
			add(btnSalvar = new JButton("Salvar"));
			add(btnSair = new JButton("Sair"));
			add(btnLimpar = new JButton("Limpar"));
			
			btnSalvar.addActionListener(this);
			btnSair.addActionListener(this);
			btnLimpar.addActionListener(this);
		}
		
		public void actionPerformed(ActionEvent evt)
		{
			if(evt.getSource() == btnSalvar)
				if(centro.dadosValidos())
				{
					//Mostrar dados do ClienteVisao
					JOptionPane.showMessageDialog(null,centro.toString(), "Cliente Visao", JOptionPane.INFORMATION_MESSAGE);
					
				}
				else 
				{
					JOptionPane.showMessageDialog(null, "Dados Incorrectos!", "Erro", JOptionPane.ERROR_MESSAGE);
					centro.limparCampos();
				}
			else if(evt.getSource() == btnSair)
				dispose();
			else
				centro.limparCampos();		
		}
	}
	
	public static void main(String args[])
	{
		new ClienteVisao();
	} 
}
