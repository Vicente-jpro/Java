/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projdeprogramacao3;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Agenda {

    LinkedList<Actividade> listaDeActividades;

    Agenda() {

        listaDeActividades = new LinkedList();
    }

    public void adicionarActividade(Actividade nova) {
        listaDeActividades.add(nova); // 1

        /*
        Complexidade: f(n) = 1 => O(n) = 1
        
         */
    }

    public void removerActividade(int id) {
        if (!vazia()) { // 1
            listaDeActividades.remove(id); // n
        } else {
            System.out.println("Não existe registo na agenda"); // 1
        }
        /*
        Complexidade: f(n) = n + 2 => O(n) = n
        
         */
    }

    public Actividade editarActividade(int id) {
        return listaDeActividades.get(id); // n
         /*
        Complexidade: f(n) = n => O(n) = n
        
         */
    }

    public boolean verificarRegisto(String nome) {

        if (!vazia()) { // 1 

            for (Actividade actividade : listaDeActividades) { // n
                String nomeProjecto = actividade.getProjeto();  // n
                // Se a actividade existe 
                if (nomeProjecto.equalsIgnoreCase(nome)) { // n
                    return true; // 1
                }
            }

        }

        return false; // 1
        /*
        Complexidade: f(n) = 3n + 3=> O(n) = n
        
         */
    }

    public boolean verificarDataRegisto(Data dataInserida) {

        if (!vazia()) { // 1
            String dataDaActividade = ""; // 1
            for (Actividade actividade : listaDeActividades) { // n
                // Se a actividade existe 
                if (actividade.getDataDaActividade().dia == dataInserida.dia) { // n
                    dataDaActividade = actividade.getDataDaActividade().getMes(); // n
                    if (dataDaActividade.equalsIgnoreCase(dataInserida.getMes())) { // n
                        if (actividade.getDataDaActividade().ano == dataInserida.ano) { // n
                            return true; // 1
                        }
                    }
                }
            }

        }

        return false; // 1
        /*
        Complexidade: f(n) = 5n + 4 => O(n) = n
        
         */
    }

    //Verificar a existência de um registo especifico em um intervalo de hora
    public boolean verificarIntervaloHoraRegisto(Hora horaInical, Hora horaFinal) {

        if (!vazia()) { // 1

            for (Actividade actividade : listaDeActividades) { // n

                int horaRegisto = actividade.getHora().getHora(); // n
                if (horaInical.getHora() <= horaRegisto) { // n
                    if (horaRegisto <= horaFinal.getHora()) { // n
                        return true; // 1
                    }
                }

            }

        }

        return false; // 1
        /*
        Complexidade: f(n) = 4n + 3 => O(n) = n
        
         */
    }

    // verificar se a estrutura está vazia
    public boolean vazia() {

        return listaDeActividades.isEmpty(); // 1
        /*
        Complexidade: f(n) = 1 => O(n) = 1
        
         */
    }

    // pegar o Actividade relacionada a um mẽs
    public Object[] verificarDiasVaziosMes(Data data) {

        Object[] diasDoMes = new Object[31]; // 1
        String mesInserido = null; // 1
        if (!vazia()) { // 1

            int posicao = 0; // 1
            // Pervorrer todas as actividades
            for (Actividade actividade : listaDeActividades) { // n

                String mesRegisto = actividade.getDataDaActividade().getMes(); // n
                mesInserido = data.getMes(); // n
                // Se o mes da actifidade for igual ao mes digitado
                if (mesRegisto.equalsIgnoreCase(mesInserido)) { //n

                    // pegar o dia do registo da actividade
                    int dia = actividade.getDataDaActividade().dia; // n
                    // colocar o dia em um array de meses
                    diasDoMes[dia - 1] = dia; // n

                }
                posicao++; // n
            }

        }

        return diasDoMes; // 1
        /*
        Complexidade: f(n) = 7n + 5 => O(n) = n
        
         */
    }

    public Object[] verificarMesesVaziosAno(Data data) {

        Object[] mesDoAno = new String[12]; // 1 
        String mes = ""; // 1
        int anoInserido = 0; // 1
        ;
        if (!vazia()) { // 1

            int posicao = 0; // 1
            // Pervorrer todas as actividades
            for (Actividade actividade : listaDeActividades) { // n

                int anoRegisto = actividade.getDataDaActividade().ano; // n
                anoInserido = data.ano; // n
                // Se o ano da actifidade for igual ao ano digitado
                if (anoRegisto == anoInserido) { // n

                    // pegar o mes do registo da actividade
                    mes = actividade.getDataDaActividade().getMes(); // n
                    int posicaoMes = actividade.getDataDaActividade().getPosicaoMes(); // n
                    // colocar o mes em um array de meses
                    mesDoAno[posicaoMes] = mes; // n

                }
                posicao++; // n
            }

        }

        return mesDoAno; // 1
        /*
        Complexidade: f(n) = 8n + 6 => O(n) = n
        
         */
    }

    // verificar meses com mais demanda
    public List<Demanda> verificarMesesMaisDemanda() {

        Data data = new Data(); // 1
        List<Demanda> listaDemanda = new ArrayList<>(); // 1

        String[] meses = data.getTodosMeses(); // 1

        int numeroDemanda = 0; // 1

        if (!vazia()) { // 1

            Demanda deman = null; // 1
            String mesRegisto = "não definido"; // 1
            // Pervorrer todas as actividades
            for (Actividade actividade : listaDeActividades) { // n

                if (deman == null) { // n

                    deman = new Demanda(0, ""); // n
                    listaDemanda.add(deman); // n
                }

                String mesActividade = actividade.getDataDaActividade().getMes(); // n

                // Se o mês de registo da actividade for diferente do mesRegisto, então
                // Coloca na variavel mesRegisto 
                if (!mesRegisto.equalsIgnoreCase(mesActividade)) { // n
                    mesRegisto = mesActividade; // n

                    deman = new Demanda(1, mesActividade); // n
                    listaDemanda.add(deman); // n
                    // reinicia a contagem da demanda
                    numeroDemanda = 0; // n

                }

                if (!listaDemanda.isEmpty()) { // n

                    for (int i = 0; i < listaDemanda.size(); i++) { // n*n
                        String mesDaListaDemanda = listaDemanda.get(i).getMes(); // n*n

                        if (mesRegisto.equalsIgnoreCase(mesDaListaDemanda)) { // n*n

                            numeroDemanda = listaDemanda.get(i).numeroDemanda + 1; // n*n

                            deman = new Demanda(numeroDemanda, mesDaListaDemanda); // n*n
                            listaDemanda.set(i, deman); // n*n
                        }
                    }
                }

            }

        }

        return listaDemanda; // 1

        /*
        Complexidade: f(n) = 6n^2 + 11n + 8 => O(n) = n^2
        
         */
    }

    // Pegar os meses com mais demanda
    public List<Demanda> getMesComMaisDemanda(String opcao) {

        List<Demanda> listaDemanda = verificarMesesMaisDemanda(); // 1
        int demanda1; // 1
        int demanda2; // 1
        if (!listaDemanda.isEmpty()) { // 1
            for (int i = 0; i < listaDemanda.size(); i++) { // n

                for (int j = i + 1; j < listaDemanda.size(); j++) { // n*n -1

                    demanda1 = listaDemanda.get(i).numeroDemanda;  // n*n - 1
                    demanda2 = listaDemanda.get(j).numeroDemanda;  // n*n - 1

                    if (opcao.equalsIgnoreCase("mes com mais demanda")) {  // n*n - 1
                        // Remove o mês com menor demanda
                        if (demanda1 > demanda2) {  // n*n - 1
                            listaDemanda.remove(j);  // n*n - 1
                        }
                    } else {
                        // mes com menos demanda
                        // Remove o mês com mais demanda
                        if (demanda1 < demanda2) {  // n*n - 1
                            listaDemanda.remove(j);  // n*n - 1
                        }
                    }

                }

            }
        }

        return listaDemanda;  //  1

        /*
        Complexidade: f(n) = 8n² + n - 3 => O(n) = n²
        
         */
    }

    public void mostrarTodosRegistos() {

        System.err.println("********** Todas as Actividade **********"); // 1
        for (Actividade actividade : listaDeActividades) { // n

            System.err.println(actividade.toString()); // n

        }
        System.err.println("**********************************\n"); // 1
        /*
        Complexidade: f(n) = 2n + 2 => O(n) = n^2
        
         */

    }

    public void imprimirDemanda(List<Demanda> listaDemanda) {

        for (Demanda demanda : listaDemanda) { // n

            System.err.println(demanda.toString()); // n

        }
        /*
        Complexidade: f(n) = 2n => O(n) = n
        
         */

    }

    public void imprimirArrayDias(Object[] array) {

        for (int i = 0; i < array.length; i++) { // n

            String mudarLinhaDia = (i % 7 == 0) ? "\n" : ""; // n

            // Se o mês estiver vazio, mostra o dia
            if (array[i] == null) { // n

                System.err.print(" " + (i + 1) + mudarLinhaDia); // n

            }

        }

        /*
        Complexidade: f(n) = 4n  => O(n) = n
        
         */
    }

    public void imprimirArrayMeses(Object[] array) {

        Data data = new Data(); // 1
        String[] meses = data.getTodosMeses(); // 1

        for (int i = 0; i < array.length; i++) { // n

            for (int j = 0; j < meses.length; j++) { // n*n

                if (array[i] == meses[j]) { // n*n
                    meses[j] = "Agendado"; // n*n
                }
            }

        }

        // imprimir meses vazios
        for (int i = 0; i < meses.length; i++) { // n 

            String mudarLinhaMes = (i % 4 == 0) ? "\n" : ""; // n
            // Se o mês estiver vazio, mostra o dia

            System.err.println("  " + meses[i] + mudarLinhaMes); // n

        }

    }
    /*
        Complexidade: f(n) = 3n + 2 => O(n) = n
        
     */

}
