package projdeprogramacao3;

public class Data {
    int dia;
    private String mes;
    private String[] meses = {
                    "Janeiro", "Fevereiro", "Março", 
                    "Abril", "Maio", "Junho", 
                    "Julho",  "Agosto", "Setembro",
                    "Outubro", "Novembro", "Dezembro"
                    };
    private int posicaoMes;
    int ano;

     public Data() {
        this.ano = 1999;
        this.dia = 1;
    }

    public Data(int dia, int mes, int ano) {
        this.dia = dia;
        this.mes = meses[ mes - 1 ]; // Pega o mes do array
        
        this.ano = ano;
    }

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getMes() { return mes; }

    public void setMes(int mes) { this.mes = meses[ mes - 1 ]; }

    public int getPosicaoMes() {
        return posicaoMes;
    }

    public void setPosicaoMes(int posicaoMes) {
        this.posicaoMes = posicaoMes - 1;
    }

    public String[] getTodosMeses(){ return meses; }
    
    @Override
    public String toString()
    {
        return dia + "/" + mes + "/" + ano;
    }
}
