/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projdeprogramacao3;

import InterfacesJframe.ClienteVisao;
import com.sun.security.ntlm.Client;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author jessica
 */
public class ProjDeProgramacao3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new ClienteVisao().setVisible(true);
        Agenda minhaAgenda;
        minhaAgenda = new Agenda();
        int id = 0;
        // Nova actividade criada
        Actividade minhaActividade2 = new Actividade();
       
        id++;
        minhaActividade2.id = id;
        minhaActividade2.dataDaActividade.ano = 2021;
        minhaActividade2.dataDaActividade.dia = 13;
        minhaActividade2.dataDaActividade.setMes(1);
        minhaActividade2.dataDaActividade.setPosicaoMes(1);
        minhaActividade2.descricaoDaActividade = "Futebool";
        minhaActividade2.diaDaSemana = "segunda";
        minhaActividade2.hora = new Hora();
        minhaActividade2.hora.hora = 12;
        minhaActividade2.hora.minuto = 13;
        minhaActividade2.hora.segundo = 18;
        minhaActividade2.lembrete = new Data();
        minhaActividade2.lembrete.ano = 2021;
        minhaActividade2.lembrete.dia = 14;
        minhaActividade2.lembrete.setMes(3);
        minhaActividade2.local = "Ucan";
        minhaActividade2.projeto = "jogar";
        minhaActividade2.periodicidadeHabitual = true;
        minhaAgenda.adicionarActividade(minhaActividade2);

        Actividade minhaActividade3 = new Actividade();
        minhaActividade3.dataDaActividade = new Data();
        id++;
        minhaActividade3.id = id;
        minhaActividade3.dataDaActividade.ano = 2021;
        minhaActividade3.dataDaActividade.dia = 13;
        minhaActividade3.dataDaActividade.setMes(1);
        minhaActividade3.dataDaActividade.setPosicaoMes(1);
        minhaActividade3.descricaoDaActividade = "Futebool";
        minhaActividade3.diaDaSemana = "segunda";
        minhaActividade3.hora = new Hora();
        minhaActividade3.hora.hora = 10;
        minhaActividade3.hora.minuto = 13;
        minhaActividade3.hora.segundo = 18;
        minhaActividade3.lembrete = new Data();
        minhaActividade3.lembrete.ano = 2021;
        minhaActividade3.lembrete.dia = 14;
        minhaActividade3.lembrete.setMes(3);
        minhaActividade3.local = "Ucan";
        minhaActividade3.periodicidadeHabitual = true;
        minhaActividade3.projeto = "Jogar";
        minhaAgenda.adicionarActividade(minhaActividade3);

        Actividade minhaActividade4 = new Actividade();
        minhaActividade4.dataDaActividade = new Data();
        id++;
        minhaActividade4.id = id;
        minhaActividade4.dataDaActividade.ano = 2021;
        minhaActividade4.dataDaActividade.dia = 13;
        minhaActividade4.dataDaActividade.setMes(2);
        minhaActividade4.dataDaActividade.setPosicaoMes(2);
        minhaActividade4.descricaoDaActividade = "Futebool";
        minhaActividade4.diaDaSemana = "segunda";
        minhaActividade4.hora = new Hora();
        minhaActividade4.hora.hora = 9;
        minhaActividade4.hora.minuto = 13;
        minhaActividade4.hora.segundo = 18;
        minhaActividade4.lembrete = new Data();
        minhaActividade4.lembrete.ano = 2021;
        minhaActividade4.lembrete.dia = 14;
        minhaActividade4.lembrete.setMes(3);
        minhaActividade4.local = "Ucan";
        minhaActividade4.periodicidadeHabitual = true;
        minhaActividade4.projeto = "AngoFoot";
     
        minhaAgenda.adicionarActividade(minhaActividade4);

        int opcoes = -1;
        Scanner teclado = new Scanner(System.in);

        while (opcoes != 0) {
            System.err.println("Menu Principal");
            System.out.println("1. Criar Actividades");
            System.out.println("2. Remover Actividades");
            System.out.println("3. Ver Actividades");
            System.out.println("4. Editar Actividades");
            System.out.println("5. Verificar a Existencia de um Registo");
            System.out.println("6. Verificar Data de um Registo dd/mm/yyyy");
            System.out.println("7. Verificar a Existencia de um Registo em um \n"
                             + "     Intervalo de Hora Especifica");
            System.out.println("8. Verificar se a Estrutura Está Vazia");
            System.out.println("9. Verificar os Dias Vazios Dentro de um Mẽs");
            System.out.println("10. Verificar os Meses Vazios Dentro de um Ano");
            System.out.println("11. Verificar o Meses com Mais Demanda");
            System.out.println("12. Verificar o Meses com Menos Demanda");
            System.out.println("13. Mostrar Todos os Registos");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opcao: ");
            opcoes = teclado.nextInt();

            teclado = new Scanner(System.in);

            switch (opcoes) {
                case 1: //Criar Actividades
                     new ClienteVisao().setVisible(true);
                     
                    Actividade minhaActividade = new Actividade();
                    id++;
                    minhaActividade.id = id;
                    System.out.print("Digite o nome do projecto: ");
                    minhaActividade.projeto = teclado.nextLine().trim();

                    System.out.print("Digite a descricao da actividade: ");
                    minhaActividade.descricaoDaActividade = teclado.nextLine().trim();

                    minhaActividade.dataDaActividade = new Data();
                    System.out.print("Digite a data da actividade(dia): ");
                    minhaActividade.dataDaActividade.dia = teclado.nextInt();
                    teclado = new Scanner(System.in);
                    System.out.print("Digite a data da actividade(mes): ");
                    int mes = Integer.parseInt(teclado.nextLine().trim());
                    minhaActividade.dataDaActividade.setMes(mes);
                    minhaActividade.dataDaActividade.setPosicaoMes(mes);
                    System.out.print("Digite a data da actividade(ano): ");
                    minhaActividade.dataDaActividade.ano = teclado.nextInt();
                    teclado = new Scanner(System.in);

                    System.out.print("Digite o dia da semana: ");
                    minhaActividade.diaDaSemana = teclado.nextLine().trim();

                    minhaActividade.hora = new Hora();
                    System.out.print("Digite a hora(hora): ");
                    minhaActividade.hora.hora = teclado.nextInt();
                    teclado = new Scanner(System.in);
                    System.out.print("Digite a hora(minuto): ");
                    minhaActividade.hora.minuto = teclado.nextInt();
                    teclado = new Scanner(System.in);
                    System.out.print("Digite a hora(segundo): ");
                    minhaActividade.hora.segundo = teclado.nextInt();
                    teclado = new Scanner(System.in);

                    System.out.print("Digite o local: ");
                    minhaActividade.local = teclado.nextLine().trim();

                    minhaActividade.lembrete = new Data();
                    System.out.print("Digite o lembrete(dia): ");
                    minhaActividade.lembrete.dia = teclado.nextInt();
                    System.out.print("Digite o lembrete(mes): ");
                    mes = teclado.nextInt();
                    minhaActividade.lembrete.setMes(mes);
                    System.out.print("Digite o lembrete(ano): ");
                    minhaActividade.lembrete.ano = teclado.nextInt();

                    System.out.print("Digite o periodicidadeHabitual(1 = habitual, 2 = pontual): ");
                    if (teclado.nextInt() == 1) {
                        minhaActividade.periodicidadeHabitual = true;
                    } else {
                        minhaActividade.periodicidadeHabitual = false;
                    }

                    System.out.println("");

                    minhaAgenda.adicionarActividade(minhaActividade);
                    break;
                case 2: //  Remover Actividades
                     new ClienteVisao().setVisible(true);
                    for (int i = 0; i < minhaAgenda.listaDeActividades.size(); i++) {
                        System.out.println((i + 1) + ". " + minhaAgenda.listaDeActividades.get(i).projeto);
                    }
                    System.out.println("0. Cancelar a remoção");

                    System.out.print("Qual deseja remover: ");
                    id = teclado.nextInt();

                    id = id - 1;

                    if (id >= 0 && id < minhaAgenda.listaDeActividades.size()) {
                        minhaAgenda.removerActividade(id);
                    }
                    //else

                    //opcoes = -1;
                    break;
                case 3: // ver actividade
                    System.err.println("\n********************************************");
                    for (int i = 0; i < minhaAgenda.listaDeActividades.size(); i++) {
                        System.out.println((i + 1) + ". " + minhaAgenda.listaDeActividades.get(i).projeto);
                    }

                    int id2;
                    System.out.print("Qual actividade deseja ver : ");
                    id2 = teclado.nextInt();

                    teclado = new Scanner(System.in);

                    id2 = id2 - 1;

                    String periodicidade = (minhaAgenda.listaDeActividades.get(id2).periodicidadeHabitual == true) 
                            ? "habitual" : "pontual";
                    System.err.println(
                            "\n Id: " + minhaAgenda.listaDeActividades.get(id2).id
                            + "\n Projecto: " + minhaAgenda.listaDeActividades.get(id2).projeto
                            + "\n Descricão: " + minhaAgenda.listaDeActividades.get(id2).descricaoDaActividade
                            + "\n Data: " + minhaAgenda.listaDeActividades.get(id2).dataDaActividade.toString()
                            + "\n Hora: " + minhaAgenda.listaDeActividades.get(id2).hora.toString()
                            + "\n Dia da Semana: " + minhaAgenda.listaDeActividades.get(id2).diaDaSemana
                            + "\n Lembrete: " + minhaAgenda.listaDeActividades.get(id2).lembrete.toString()
                            + "\n Local: " + minhaAgenda.listaDeActividades.get(id2).local
                            + "\n Periodicidade: " + periodicidade
                    );
                    System.err.println("\n********************************************");

                    break;

                case 4:// Editar actividade
                    System.err.println("\n********************************************");
                    for (int i = 0; i < minhaAgenda.listaDeActividades.size(); i++) {
                        System.out.println((i + 1) + ". " + minhaAgenda.listaDeActividades.get(i).projeto);
                    }

                    int id3;
                    System.out.print("Qual deseja editar: ");
                    id3 = teclado.nextInt();

                    teclado = new Scanner(System.in);

                    id3 = id3 - 1;

                    Actividade editarActividade = minhaAgenda.editarActividade(id3);

                    System.out.print("Digite o nome do projecto: ");
                    editarActividade.projeto = teclado.nextLine().trim();

                    System.out.print("Digite a descricao da actividade: ");
                    editarActividade.descricaoDaActividade = teclado.nextLine().trim();

                    editarActividade.dataDaActividade = new Data();
                    System.out.print("Digite a data da actividade(dia): ");
                    editarActividade.dataDaActividade.dia = teclado.nextInt();
                    teclado = new Scanner(System.in);
                    System.out.print("Digite a data da actividade(mes): ");
                    mes = teclado.nextInt();
                    editarActividade.dataDaActividade.setMes(mes);
                    editarActividade.dataDaActividade.setPosicaoMes(mes);
                    System.out.print("Digite a data da actividade(ano): ");
                    editarActividade.dataDaActividade.ano = teclado.nextInt();
                    teclado = new Scanner(System.in);

                    System.out.print("Digite o dia da semana: ");
                    editarActividade.diaDaSemana = teclado.nextLine().trim();

                    editarActividade.hora = new Hora();
                    System.out.print("Digite a hora(hora): ");
                    editarActividade.hora.hora = teclado.nextInt();
                    teclado = new Scanner(System.in);
                    System.out.print("Digite a hora(minuto): ");
                    editarActividade.hora.minuto = teclado.nextInt();
                    teclado = new Scanner(System.in);
                    System.out.print("Digite a hora(segundo): ");
                    editarActividade.hora.segundo = teclado.nextInt();
                    teclado = new Scanner(System.in);

                    System.out.print("Digite o local: ");
                    editarActividade.local = teclado.nextLine().trim();

                    editarActividade.lembrete = new Data();
                    System.out.print("Digite o lembrete(dia): ");
                    editarActividade.lembrete.dia = teclado.nextInt();
                    System.out.print("Digite o lembrete(mes): ");
                    mes = teclado.nextInt();

                    editarActividade.lembrete.setMes(mes);
                    editarActividade.dataDaActividade.setPosicaoMes(mes);
                    System.out.print("Digite o lembrete(ano): ");
                    editarActividade.lembrete.ano = teclado.nextInt();

                    System.out.print("Digite o periodicidadeHabitual(1 = habitual, 2 = pontual): ");
                    if (teclado.nextInt() == 1) {
                        editarActividade.periodicidadeHabitual = true;
                    } else {
                        editarActividade.periodicidadeHabitual = false;
                    }

                    System.err.println("\n********************************************");

                    break;

                case 5: // Verificar a Existencia de um Registo
                    System.err.println("\n********************************************");
                    System.out.print("Digite o nome do registo: ");
                    String nome = teclado.nextLine();
                  
                    boolean existeRegisto = minhaAgenda.verificarRegisto(nome.toString());
                    if (!existeRegisto) {
                        System.err.println(" Este registo não existe: ");
                    } else {
                        System.err.println(" Este registo existe");
                    }
                    System.err.println("\n********************************************");
                    break;

                case 6: // Verificar Data de um Registo dd/mm/yyyy
                    System.err.println("\n********************************************");
                    System.out.print("Digite o dia: ");

                    int dia = Integer.parseInt(teclado.nextLine());

                    System.out.print("Digite o mês: ");
                    mes = Integer.parseInt(teclado.nextLine());

                    System.out.print("Digite o ano: ");
                    int ano = Integer.parseInt(teclado.nextLine());

                    Data data = new Data(dia, mes, ano);
                    data.setPosicaoMes(mes);

                    boolean existeDataRegisto = minhaAgenda.verificarDataRegisto(data);
                    if (!existeDataRegisto) {
                        System.err.println(" Esta data de registo não existe: ");
                    } else {
                        System.err.println(" Esta data de registo existe");
                    }
                    System.err.println("\n********************************************");
                    break;

                case 7: // Verificar a Existencia de um Registo em um Intervalo de Hora Especifica
                    System.err.println("\n********************************************");
                    Hora horaIni = new Hora();

                    System.out.print("Digite a hora inicial : ");
                    int horaInicial = Integer.parseInt(teclado.nextLine());
                    horaIni.hora = horaInicial;

                    Hora horaFin = new Hora();
                    System.out.print("Digite a hora final : ");
                    int horaFinal = Integer.parseInt(teclado.nextLine());
                    horaFin.hora = horaFinal;

                    boolean registo = minhaAgenda.verificarIntervaloHoraRegisto(horaIni, horaFin);
                    if (!registo) {
                        System.err.println(" Este registo não existe: ");
                    } else {
                        System.err.println(" Este registo existe");
                    }
                    System.err.println("\n********************************************");
                    break;

                case 8: // Verificar se a estrutura está vazia
                    System.err.println("\n********************************************");
                    boolean agenda = minhaAgenda.vazia();
                    if (!agenda) {
                        System.err.println(" Está estrutura não está vazia: ");
                    } else {
                        System.err.println(" Está estrutura está vazia");
                    }
                    System.err.println("\n********************************************");
                    break;

                case 9: // verificar dias vazios dentro de um mês
                    System.err.println("\n********************************************");
                    System.out.print("\n Digite o mês: ");
                    mes = Integer.parseInt(teclado.nextLine());
                    
                    Data dataa = new Data();
                    dataa.setMes(mes);
                    dataa.setPosicaoMes(mes);
                    Object[] meses = minhaAgenda.verificarDiasVaziosMes(dataa);
                    minhaAgenda.imprimirArrayDias(meses);
                    System.err.println("\n********************************************");
                    break;

                case 10: // verificar meses vazios dentro de um ano
                    System.err.println("\n********************************************");
                    System.out.print("\n Digite o ano: ");
                    ano = Integer.parseInt(teclado.nextLine());

                    Data data2 = new Data();
                    data2.ano = ano;
                    Object[] mesesAno = minhaAgenda.verificarMesesVaziosAno(data2);
                    minhaAgenda.imprimirArrayMeses(mesesAno);
                    System.err.println("\n********************************************");
                    break;

                case 11: // verificar meses com mais demanda
                    System.err.println("\n********************************************");
                    System.err.println("\n Mês ou Meses com mais Demanda: ");

                    List<Demanda> listaDemanda = minhaAgenda.getMesComMaisDemanda("mes com mais demanda");
                    minhaAgenda.imprimirDemanda(listaDemanda);
                    System.err.println("\n********************************************");
                    break;

                case 12: // verificar meses com menos demanda
                    System.err.println("\n********************************************");
                    System.err.println("\n Mês ou Meses com menos Demanda: ");

                    List<Demanda> listaDemanda2 = minhaAgenda.getMesComMaisDemanda("mes com menos demanda");
                    minhaAgenda.imprimirDemanda(listaDemanda2);
                    System.err.println("\n********************************************");
                    break;

                case 13:
                    // mostrar todos os registos
                    System.err.println("\n********************************************");
                    System.err.println("\n Mostrar todos os registos: ");
                    minhaAgenda.mostrarTodosRegistos();
                    System.err.println("\n********************************************");
                    break;
            }
        }
    }

}
