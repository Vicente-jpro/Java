/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projdeprogramacao3;

public class Actividade {

    private int id;
    private String[] diasDaSemana = {"Segunda", "Terça", "Quinta", "Sexta", "Sabado", "Domingo"};
    private String semana;
    private Data dataDaActividade;
    private Hora hora;
    private String descricaoDaActividade;
    private String local;
    private Data lembrete;
    private boolean periodicidadeHabitual;
    private String projeto;

    public Actividade() {
        this.id = 0;
        this.semana = diasDaSemana[0];
        this.dataDaActividade = new Data();
        this.hora = new Hora();
        this.descricaoDaActividade = "Sem descrição";
        this.local = "Sem local";
        this.lembrete = new Data();
        this.periodicidadeHabitual = true;
    }

    public Actividade(int id, String semana, String descricaoDaActividade, String local, boolean periodicidadeHabitual, String projeto) {
        this.id = id;
        this.semana = semana;
        this.dataDaActividade = new Data();
        this.hora = new Hora();
        this.descricaoDaActividade = descricaoDaActividade;
        this.local = local;
        this.lembrete = new Data();
        this.periodicidadeHabitual = periodicidadeHabitual;
        this.projeto = projeto;
    }

    public int getId() {
        return id;
    }

    public String getDiaDaSemana() {
        return semana;
    }

    public void setDiaDaSemana(int diaDaSemana) {
        this.semana = diasDaSemana[diaDaSemana];
    }

    public Data getDataDaActividade() {
        return dataDaActividade;
    }

    public void setDataDaActividade(Data dataDaActividade) {
        this.dataDaActividade = dataDaActividade;
    }

    public Hora getHora() {
        return hora;
    }

    public void setHora(Hora hora) {
        this.hora = hora;
    }

    public String getDescricaoDaActividade() {
        return descricaoDaActividade;
    }

    public void setDescricaoDaActividade(String descricaoDaActividade) {
        this.descricaoDaActividade = descricaoDaActividade;
    }

    public String getLocal() {
        return local;
    }

    public void setLocal(String local) {
        this.local = local;
    }

    public Data getLembrete() {
        return lembrete;
    }

    public void setLembrete(Data lembrete) {
        this.lembrete = lembrete;
    }

    public boolean isPeriodicidadeHabitual() {
        return periodicidadeHabitual;
    }

    public void setPeriodicidadeHabitual(boolean periodicidadeHabitual) {
        this.periodicidadeHabitual = periodicidadeHabitual;
    }

    public String getProjeto() {
        return projeto;
    }

    public void setProjeto(String projeto) {
        this.projeto = projeto;
    }

    public String[] getDiasDaSemana() {
        return diasDaSemana;
    }

    @Override
    public String toString() {

        String periodicidade = (periodicidadeHabitual == true) ? "habitual" : "pontual";

        return "\n Id: " + id
                + "\n Projecto: " + projeto
                + "\n Descricão: " + descricaoDaActividade
                + "\n Data: " + dataDaActividade.toString()
                + "\n Hora: " + hora.toString()
                + "\n Dia da Semana: " + getDiaDaSemana()
                + "\n Lembrete: " + lembrete.toString()
                + "\n Local: " + local
                + "\n Periodicidade: " + periodicidade;

    }

}
